import { useState, useEffect } from 'react';

// ===== NAVBAR =====
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-gray-900/95 backdrop-blur-md shadow-lg' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-cyan-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">&lt;/&gt;</span>
            </div>
            <span className="text-white font-bold text-xl">CodeWorld</span>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#home" className="text-gray-300 hover:text-emerald-400 transition-colors">Главная</a>
            <a href="#languages" className="text-gray-300 hover:text-emerald-400 transition-colors">Языки</a>
            <a href="#code" className="text-gray-300 hover:text-emerald-400 transition-colors">Примеры кода</a>
            <a href="#resources" className="text-gray-300 hover:text-emerald-400 transition-colors">Ресурсы</a>
            <a href="#contact" className="text-gray-300 hover:text-emerald-400 transition-colors">Контакты</a>
          </div>

          <button 
            className="md:hidden text-white"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {menuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className="md:hidden bg-gray-900/95 backdrop-blur-md border-t border-gray-800">
          <div className="px-4 py-3 space-y-2">
            <a href="#home" className="block text-gray-300 hover:text-emerald-400 py-2" onClick={() => setMenuOpen(false)}>Главная</a>
            <a href="#languages" className="block text-gray-300 hover:text-emerald-400 py-2" onClick={() => setMenuOpen(false)}>Языки</a>
            <a href="#code" className="block text-gray-300 hover:text-emerald-400 py-2" onClick={() => setMenuOpen(false)}>Примеры кода</a>
            <a href="#resources" className="block text-gray-300 hover:text-emerald-400 py-2" onClick={() => setMenuOpen(false)}>Ресурсы</a>
            <a href="#contact" className="block text-gray-300 hover:text-emerald-400 py-2" onClick={() => setMenuOpen(false)}>Контакты</a>
          </div>
        </div>
      )}
    </nav>
  );
}

// ===== HERO SECTION =====
function HeroSection() {
  const codeLines = [
    'const future = await learnToCode();',
    'if (passion) { buildAmazingThings(); }',
    'while (alive) { keepLearning(); }',
  ];

  const [currentLine, setCurrentLine] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentLine(prev => (prev + 1) % codeLines.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900"></div>
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500 rounded-full filter blur-[128px] animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500 rounded-full filter blur-[128px] animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-purple-500 rounded-full filter blur-[128px] animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)',
        backgroundSize: '50px 50px'
      }}></div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="mb-6 inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-4 py-2">
          <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
          <span className="text-emerald-400 text-sm font-medium">Добро пожаловать в мир кода</span>
        </div>

        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
          Создавай.{' '}
          <span className="bg-gradient-to-r from-emerald-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent">
            Программируй.
          </span>
          <br />
          Вдохновляй.
        </h1>

        <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-10">
          Погрузись в удивительный мир программирования. Изучай языки, осваивай технологии и создавай будущее вместе с нами.
        </p>

        {/* Code preview */}
        <div className="max-w-md mx-auto mb-10 bg-gray-800/50 backdrop-blur-sm border border-gray-700 rounded-xl p-4 text-left font-mono">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
            <span className="text-gray-500 text-xs ml-2">app.js</span>
          </div>
          <div className="transition-all duration-500">
            <span className="text-purple-400">const</span>{' '}
            <span className="text-cyan-400">future</span>{' '}
            <span className="text-white">=</span>{' '}
            <span className="text-yellow-400">await</span>{' '}
            <span className="text-emerald-400">learnToCode</span>
            <span className="text-white">();</span>
            <span className="inline-block w-2 h-5 bg-emerald-400 ml-1 animate-pulse"></span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a href="#languages" className="px-8 py-4 bg-gradient-to-r from-emerald-500 to-cyan-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-emerald-500/25 transition-all duration-300 hover:-translate-y-1">
            Начать изучение
          </a>
          <a href="#code" className="px-8 py-4 bg-gray-800 border border-gray-700 text-white font-semibold rounded-xl hover:bg-gray-700 transition-all duration-300 hover:-translate-y-1">
            Смотреть примеры
          </a>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { value: '700+', label: 'Языков программирования' },
            { value: '27M+', label: 'Разработчиков в мире' },
            { value: '∞', label: 'Возможностей' },
            { value: '24/7', label: 'Сообщество' },
          ].map((stat, i) => (
            <div key={i} className="text-center">
              <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
              <div className="text-sm text-gray-400">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ===== LANGUAGES SECTION =====
function LanguagesSection() {
  const languages = [
    { name: 'Python', icon: '🐍', color: 'from-yellow-400 to-blue-500', desc: 'Универсальный язык для AI, веб-разработки и автоматизации', popularity: 95 },
    { name: 'JavaScript', icon: '⚡', color: 'from-yellow-400 to-yellow-600', desc: 'Язык веба — работает в браузере и на сервере', popularity: 98 },
    { name: 'TypeScript', icon: '🔷', color: 'from-blue-400 to-blue-600', desc: 'Типизированный JavaScript для масштабных проектов', popularity: 88 },
    { name: 'Rust', icon: '🦀', color: 'from-orange-500 to-red-600', desc: 'Безопасный и быстрый язык для системного программирования', popularity: 75 },
    { name: 'Go', icon: '🐹', color: 'from-cyan-400 to-blue-500', desc: 'Простой и эффективный язык для микросервисов', popularity: 80 },
    { name: 'Swift', icon: '🍎', color: 'from-orange-400 to-red-500', desc: 'Создавай приложения для Apple экосистемы', popularity: 72 },
    { name: 'Java', icon: '☕', color: 'from-red-500 to-orange-500', desc: 'Надёжный язык для enterprise и Android разработки', popularity: 85 },
    { name: 'C++', icon: '⚙️', color: 'from-blue-600 to-indigo-600', desc: 'Максимальная производительность для игр и систем', popularity: 78 },
  ];

  return (
    <section id="languages" className="py-24 bg-gray-900 relative">
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0)',
        backgroundSize: '40px 40px'
      }}></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <span className="text-emerald-400 font-medium text-sm uppercase tracking-wider">Языки программирования</span>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mt-3 mb-4">
            Популярные языки <span className="bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">2024</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Выбери свой путь в мире разработки. Каждый язык уникален и открывает новые возможности.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {languages.map((lang, i) => (
            <div
              key={i}
              className="group relative bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-6 hover:border-emerald-500/50 transition-all duration-300 hover:-translate-y-2 hover:shadow-xl hover:shadow-emerald-500/10"
            >
              <div className="text-4xl mb-4">{lang.icon}</div>
              <h3 className="text-xl font-bold text-white mb-2">{lang.name}</h3>
              <p className="text-gray-400 text-sm mb-4">{lang.desc}</p>
              <div className="mt-auto">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-gray-500">Популярность</span>
                  <span className="text-emerald-400">{lang.popularity}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full bg-gradient-to-r ${lang.color} transition-all duration-1000`}
                    style={{ width: `${lang.popularity}%` }}
                  ></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ===== CODE EXAMPLES SECTION =====
function CodeSection() {
  const [activeTab, setActiveTab] = useState(0);

  const examples = [
    {
      language: 'Python',
      color: 'text-yellow-400',
      code: `# Быстрая сортировка на Python
def quicksort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quicksort(left) + middle + quicksort(right)

print(quicksort([3, 6, 8, 10, 1, 2, 1]))`,
    },
    {
      language: 'JavaScript',
      color: 'text-yellow-300',
      code: `// Fetch API с async/await
async function fetchUserData(userId) {
  try {
    const response = await fetch(
      \`/api/users/\${userId}\`
    );
    if (!response.ok) {
      throw new Error('Пользователь не найден');
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Ошибка:', error.message);
  }
}`,
    },
    {
      language: 'Rust',
      color: 'text-orange-400',
      code: `// Безопасная работа с памятью в Rust
fn main() {
    let greeting = String::from("Привет, мир!");
    
    let words: Vec<&str> = greeting
        .split_whitespace()
        .collect();
    
    for word in &words {
        println!("Слово: {}", word);
    }
    
    println!("Всего слов: {}", words.len());
}`,
    },
    {
      language: 'TypeScript',
      color: 'text-blue-400',
      code: `// Типобезопасный интерфейс
interface User {
  id: number;
  name: string;
  email: string;
  role: 'admin' | 'user' | 'guest';
}

function greetUser(user: User): string {
  const prefix = user.role === 'admin' 
    ? '👑' : '👤';
  return \`\${prefix} Привет, \${user.name}!\`;
}

const admin: User = {
  id: 1, name: "Алексей",
  email: "alex@code.dev", role: "admin"
};`,
    },
  ];

  return (
    <section id="code" className="py-24 bg-gradient-to-b from-gray-900 to-gray-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-emerald-400 font-medium text-sm uppercase tracking-wider">Примеры кода</span>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mt-3 mb-4">
            Красота <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">кода</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Посмотри, как элегантно решаются задачи на разных языках программирования.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* Tabs */}
          <div className="flex flex-wrap gap-2 mb-6">
            {examples.map((ex, i) => (
              <button
                key={i}
                onClick={() => setActiveTab(i)}
                className={`px-4 py-2 rounded-lg font-medium text-sm transition-all duration-300 ${
                  activeTab === i
                    ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/25'
                    : 'bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700'
                }`}
              >
                {ex.language}
              </button>
            ))}
          </div>

          {/* Code block */}
          <div className="bg-gray-950 border border-gray-700 rounded-2xl overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3 bg-gray-900 border-b border-gray-700">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
              <span className={`text-sm font-mono ${examples[activeTab].color}`}>
                {examples[activeTab].language}
              </span>
            </div>
            <pre className="p-6 overflow-x-auto">
              <code className="text-sm sm:text-base font-mono text-gray-300 leading-relaxed whitespace-pre">
                {examples[activeTab].code}
              </code>
            </pre>
          </div>
        </div>
      </div>
    </section>
  );
}

// ===== RESOURCES SECTION =====
function ResourcesSection() {
  const resources = [
    {
      icon: '📚',
      title: 'Документация',
      desc: 'Официальная документация — лучший друг разработчика. MDN, docs.python.org, rust-lang.org.',
      tags: ['MDN', 'Docs', 'API'],
    },
    {
      icon: '🎓',
      title: 'Онлайн-курсы',
      desc: 'Структурированное обучение на платформах: Stepik, Coursera, freeCodeCamp, The Odin Project.',
      tags: ['Stepik', 'Coursera', 'freeCodeCamp'],
    },
    {
      icon: '💻',
      title: 'Практика',
      desc: 'Решай задачи на LeetCode, Codewars, HackerRank. Участвуй в open-source проектах на GitHub.',
      tags: ['LeetCode', 'Codewars', 'GitHub'],
    },
    {
      icon: '👥',
      title: 'Сообщество',
      desc: 'Общайся с разработчиками на Stack Overflow, Reddit, Discord-серверах и Telegram-чатах.',
      tags: ['StackOverflow', 'Reddit', 'Discord'],
    },
    {
      icon: '🛠️',
      title: 'Инструменты',
      desc: 'VS Code, Git, Docker, терминал — освоить эти инструменты нужно каждому разработчику.',
      tags: ['VS Code', 'Git', 'Docker'],
    },
    {
      icon: '🚀',
      title: 'Проекты',
      desc: 'Создавай свои проекты: от простых калькуляторов до полноценных веб-приложений и игр.',
      tags: ['Pet-projects', 'Portfolio', 'Deploy'],
    },
  ];

  return (
    <section id="resources" className="py-24 bg-gray-800 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-emerald-400 font-medium text-sm uppercase tracking-wider">Ресурсы</span>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mt-3 mb-4">
            Путь <span className="bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">разработчика</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg">
            Всё, что нужно для успешного старта и роста в мире программирования.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((res, i) => (
            <div
              key={i}
              className="bg-gray-900/50 border border-gray-700/50 rounded-2xl p-6 hover:border-emerald-500/30 transition-all duration-300 group"
            >
              <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">{res.icon}</div>
              <h3 className="text-xl font-bold text-white mb-2">{res.title}</h3>
              <p className="text-gray-400 text-sm mb-4 leading-relaxed">{res.desc}</p>
              <div className="flex flex-wrap gap-2">
                {res.tags.map((tag, j) => (
                  <span key={j} className="px-2 py-1 bg-gray-800 border border-gray-700 rounded-md text-xs text-gray-400">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ===== TIMELINE SECTION =====
function TimelineSection() {
  const milestones = [
    { year: '1957', event: 'FORTRAN', desc: 'Первый высокоуровневый язык программирования' },
    { year: '1972', event: 'C', desc: 'Язык, на котором написан Unix и многое другое' },
    { year: '1991', event: 'Python', desc: 'Простой и мощный язык, покоривший мир' },
    { year: '1995', event: 'Java', desc: '«Написано однажды — работает везде»' },
    { year: '1995', event: 'JavaScript', desc: 'Язык, ожививший веб-страницы' },
    { year: '2010', event: 'Go', desc: 'Ответ Google на сложность системного кода' },
    { year: '2015', event: 'Rust', desc: 'Безопасность без компромиссов в скорости' },
    { year: '2023', event: 'AI Coding', desc: 'Эра ИИ-ассистентов для разработчиков' },
  ];

  return (
    <section className="py-24 bg-gradient-to-b from-gray-800 to-gray-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-emerald-400 font-medium text-sm uppercase tracking-wider">История</span>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mt-3 mb-4">
            Эволюция <span className="bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">программирования</span>
          </h2>
        </div>

        <div className="relative">
          {/* Line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-emerald-500 via-cyan-500 to-purple-500"></div>

          {milestones.map((item, i) => (
            <div key={i} className={`relative flex items-center mb-8 ${i % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
              {/* Dot */}
              <div className="absolute left-8 md:left-1/2 w-4 h-4 bg-emerald-400 rounded-full transform -translate-x-1/2 border-4 border-gray-900 z-10"></div>
              
              {/* Content */}
              <div className={`ml-16 md:ml-0 md:w-1/2 ${i % 2 === 0 ? 'md:pr-12 md:text-right' : 'md:pl-12'}`}>
                <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4 hover:border-emerald-500/30 transition-all">
                  <span className="text-emerald-400 font-mono text-sm">{item.year}</span>
                  <h3 className="text-lg font-bold text-white">{item.event}</h3>
                  <p className="text-gray-400 text-sm">{item.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ===== FOOTER =====
function Footer() {
  return (
    <footer id="contact" className="bg-gray-950 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-cyan-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">&lt;/&gt;</span>
              </div>
              <span className="text-white font-bold text-xl">CodeWorld</span>
            </div>
            <p className="text-gray-400 max-w-sm mb-6">
              Платформа для тех, кто хочет погрузиться в мир программирования. Учись, создавай, вдохновляй.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 bg-gray-800 border border-gray-700 rounded-lg flex items-center justify-center text-gray-400 hover:text-emerald-400 hover:border-emerald-500/50 transition-all">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 border border-gray-700 rounded-lg flex items-center justify-center text-gray-400 hover:text-emerald-400 hover:border-emerald-500/50 transition-all">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>
              </a>
              <a href="#" className="w-10 h-10 bg-gray-800 border border-gray-700 rounded-lg flex items-center justify-center text-gray-400 hover:text-emerald-400 hover:border-emerald-500/50 transition-all">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Навигация</h3>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-400 hover:text-emerald-400 transition-colors text-sm">Главная</a></li>
              <li><a href="#languages" className="text-gray-400 hover:text-emerald-400 transition-colors text-sm">Языки</a></li>
              <li><a href="#code" className="text-gray-400 hover:text-emerald-400 transition-colors text-sm">Примеры</a></li>
              <li><a href="#resources" className="text-gray-400 hover:text-emerald-400 transition-colors text-sm">Ресурсы</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Технологии</h3>
            <ul className="space-y-2">
              <li><span className="text-gray-400 text-sm">React + TypeScript</span></li>
              <li><span className="text-gray-400 text-sm">Tailwind CSS</span></li>
              <li><span className="text-gray-400 text-sm">Vite</span></li>
              <li><span className="text-gray-400 text-sm">Node.js</span></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">© 2024 CodeWorld. Все права защищены.</p>
          <p className="text-gray-500 text-sm">Сделано с ❤️ и ☕</p>
        </div>
      </div>
    </footer>
  );
}

// ===== MAIN APP =====
export default function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Navbar />
      <HeroSection />
      <LanguagesSection />
      <CodeSection />
      <ResourcesSection />
      <TimelineSection />
      <Footer />
    </div>
  );
}
